import { useKeycloak } from '@react-keycloak/web';
import React from 'react'
import { Image } from 'react-bootstrap'
import ReactStars from 'react-stars'
import { useAppDispatch } from '../../hooks/redux';
import { setIncreaseItemQTY, setRemoveItemFromCart } from '../../store/slices/carts/CartSlice';

export const CardBasket = ({ book }: any) => {
  const dispatch = useAppDispatch();
  const { keycloak } = useKeycloak();
  const {
    product,
    title,
    text,
    img,
    price,
    cartQuantity,
    isbn
  } = book;

  const onRemoveItem = () => {
    dispatch(
      setRemoveItemFromCart({
        product,
        title,
        text,
        img,
        price,
        cartQuantity,
        isbn,
        token: keycloak.token,
      })
    );
  };

  const changeQty = (e: any, book: any) => {
    e.preventDefault();
    dispatch(setIncreaseItemQTY({ book, newqty: e.target.value }))
  }
  return (
    <div className="basket-item" >
      <div className="item-info-wrap">
        <div className="item-img">
          <Image src={book?.img} rounded={true} className="item-img" alt='Dan Abramov' />
        </div>
        <div className="item-info">
          <h2>{book?.title}</h2>
          <div className="price-wrap">
            <span className="price">ISBN: {book?.isbn ? book?.isbn : "N/A"}</span>
          </div>
          <ReactStars
            size={24}
            color2={"#ffc754"}
            value={parseInt(book?.rating)}
          />
          <div className="price-wrap">
            <span className="price">{book?.price}</span>
          </div>
        </div>
      </div>
      <div className="item-checkout-info">
        <div className="Qty">
          <label htmlFor="Qty_1">Cantidad</label>
          <select id="Qty_1" className="Qty-select input-sm" value={book.cartQuantity} onChange={(e) => changeQty(e, book)} name="quantity" >
            <option defaultValue="1" >1</option>
            <option defaultValue="2" >2</option>
            <option defaultValue="3" >3</option>
            <option defaultValue="4" >4</option>
            <option defaultValue="5" >5</option>
            <option defaultValue="6" >6</option>
            <option defaultValue="7" >7</option>
          </select>
        </div>
        <span className="price-total">${parseInt(book?.price.toString().slice(1)) * book.cartQuantity}</span>
        <button className="btn-delete" onClick={onRemoveItem}>Eliminar</button>
      </div>
    </div>
  )
}
