import { useKeycloak } from "@react-keycloak/web";
import { Link, useNavigate } from "react-router-dom";
import { useAppDispatch } from "../../hooks/redux";
import { setAddItemToCart } from "../../store/slices/carts/CartSlice";

const Card = ({ book }: any) => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { keycloak, initialized } = useKeycloak();

  const onAddToCart = () => {
    const item = {
      isbn: book.isbn13,
      title: book.title,
      text: book.subtitle,
      img: book.image,
      price: book.price,
      token: keycloak.token,
    };
     dispatch(setAddItemToCart(item)); 
    console.log('añadido.....',item);
    
  };

  return (
    <div className="supply-product">
      <p onClick={() => navigate(`/books/${book.isbn13}`)}>
        <img src={book.image} className="product-image" alt="img" />
        <h2 className="product-title">{book.title}</h2>
      </p>
      {book.subtitle ? (
        <h2 className="product-subtitle">{book.subtitle.substr(0, 12)}</h2>
      ) : null}

      <h2 className="product-isbn">ISBN: {book.isbn13}</h2>

      <div className="price-container">
        <h2 className="product-price">{book.price}</h2>
      </div>

      <button
        style={{
          width: "100%",
          height: "37px",
          marginTop: 10,
          backgroundColor: "#10bbd5",
        }}
        onClick={() => {
          onAddToCart();
        }}
      >
        Add to Basket
      </button>
    </div>
  );
};

export default Card;
