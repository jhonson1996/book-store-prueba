import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { useKeycloak } from '@react-keycloak/web';
import { CardElement, useElements, useStripe, PaymentElement } from '@stripe/react-stripe-js';
import { setClearCartItems, setCloseCart } from '../../store/slices/carts/CartSlice';

export const PaymentForm = ({ cartTotalAmount }:any) => {
  
  const stripe = useStripe();
  const elements = useElements();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { keycloak } = useKeycloak();

  const [error, setError] = useState(null);
  const [cardComplete, setCardComplete] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState(null);
  const [data, setData] = useState({
    email: '',
    name: '',
  });

  const handleSubmit = async (event:any) => {
    event.preventDefault();

    if (!stripe || !elements) {
      // Stripe.js has not loaded yet. Make sure to disable
      // form submission until Stripe.js has loaded.
      return;
    }

    const card = elements.getElement(CardElement);

    if (card == null) {
      return;
    }

    if (error) {
      card.focus();
      return;
    }

    if (cardComplete) {
      setProcessing(true);
    }

    const payload = await stripe.createPaymentMethod({
      type: 'card',
      card,
      billing_details: data,
    });

    setProcessing(false);

    /* if (payload.error) {
      setError(payload.error);
    } else {
      console.log(
        payload.paymentMethod.id,
        payload.paymentMethod.billing_details
      );
      const { id, billing_details } = payload.paymentMethod;
      const dataPurchase = {
        id,
        email: billing_details.email,
        name: billing_details.name,
        amount: Math.round(cartTotalAmount * 100),
        description: 'Compra de libros',
      };
      /* const response = await fetch('http://localhost:3500/api/checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(dataPurchase),
      });
      const result = await response.json();
      console.log(result);
      if (result.status !== 'ok') {
        setError({
          message: `Error:${result.message.code} by ${result.message.decline_code}`,
        });
        return;
      } 
      const token = keycloak.token;
      dispatch(setClearCartItems(token));
      dispatch(setCloseCart({ cartState: false }));
      setPaymentMethod(payload.paymentMethod);
    } */
  };

  const reset = () => {
    setError(null);
    setProcessing(false);
    setPaymentMethod(null);
    setData({
      email: '',
      name: '',
    });
    navigate('/books');
  };

  return (
    <>
      <form className='form-payment' onSubmit={handleSubmit}>
        <h2>Digite los datos para el pago</h2>
        <PaymentElement/>
        <button
          /* onClick={handleSearch} */
          aria-label="Search"
          className="btn-payment "
          type="submit"
        >
          <span className="text">Pagar ${cartTotalAmount}</span>
        </button>
      </form>
    </>
  )

}