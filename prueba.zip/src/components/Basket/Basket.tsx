import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../../hooks/redux";

import cartItemsIcon from '../../assets/basketIcon.svg'
import Card from "../Card/Card";
import { setGetTotals, setIncreaseItemQTY, setRemoveItemFromCart } from "../../store/slices/carts/CartSlice";
import { CardBasket } from "../CardBasket/CardBasket";



export default function Basket() {
  const { cartItems,cartTotalAmount } = useAppSelector((state) => state.cartSlice);
  const [total, setTotal] = useState(0)
  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(setGetTotals());
  }, [cartItems, dispatch])

  return (
    <div className="basket-page">
      <h1 className="basket-page-title">Tus Libros</h1>
      <div className="basket-items-wrap">
        <div className="basket-header">
          <h2>Detalles de tu cesta</h2>
        </div>
        {
          cartItems?.map((book: any, i: number) => (
            <CardBasket book={book} key={i} />
          ))
        }
      </div>
      <div className="basket-totals-wrap">
        <div className="basket-totals">
          <dl className="delivery-text">
            <dt>Gastos de envío</dt>
            <dd>GRATIS</dd>
          </dl>
          <dl className="total">
            <dt>Total</dt>
            <dd>${cartTotalAmount}</dd>
          </dl>
          <Link to="/payments">
            <button
              /* onClick={handleSearch} */
              aria-label="Search"
              className="header-search-btn"
              type="submit"
            >
              <span className="text">Comprar</span>
            </button>
          </Link>
        </div>
        <div className="basket-checkout-btn-wrap"></div>
      </div>
    </div>

  )
}