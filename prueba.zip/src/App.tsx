import Routes from "./routes/Routes";
import { ReactKeycloakProvider } from "@react-keycloak/web";
import keycloak from "../src/keycloak";
import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import { useEffect, useState } from "react";
import axios from "axios";
function App() {
  /* const stripePromise = loadStripe("pk_test_51HvnNeL30FHPDItuIKCjXY5WvLhj3LpF8hINA05zGAQr5eBfJBjB853s0YIF8Q4qXTRcc3yzDR84nDrQGySudPq50041BZ5aU9"); */
  const [clientSecret, setClientSecret] = useState()
  /* useEffect(() => {
    axios.post('http://localhost:3001/api/checkout', {
      id: 1,
      amount: 100,
    })
      .then(function (response) {
        console.log(response.data.clientSecret);
        setClientSecret(response.data.clientSecret)
      })
      .catch(function (error) {
        console.log(error);
      });
  }, []); */

  return (
    <ReactKeycloakProvider authClient={keycloak}>
      {/* <Elements stripe={stripePromise} options={{ clientSecret }}> */}
        <Routes />
       {/* </Elements> */}
     </ReactKeycloakProvider> 
  );
}

export default App;
