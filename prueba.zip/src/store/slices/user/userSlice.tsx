import { createSlice } from "@reduxjs/toolkit";

export interface userState {
  nombre: string,
  email: string,
  avatar: string
}

const initialState: userState = {
    nombre: "",
    email: "",
    avatar: ""
};

export const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setUser: (state, action) => {
        state.nombre=action?.payload?.data?.name
        state.email=action?.payload?.data?.email
        state.avatar=action?.payload?.data?.name
        
        console.log(action.payload.data);
        
    },
  },
});

export const { setUser } = userSlice.actions;