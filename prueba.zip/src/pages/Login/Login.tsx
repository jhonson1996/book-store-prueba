import React, { useEffect } from "react";

const Login = () => {
 
  return (
    <div className="main">
      <h1>Bienvenido</h1>
    </div>
  );
};

export default Login;
