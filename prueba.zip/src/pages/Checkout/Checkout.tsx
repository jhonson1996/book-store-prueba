import React from 'react'

const Checkout = () => {
  return (
    <div>
      
    </div>
  )
}

export default Checkout
