import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";
import ReactStars from "react-stars";
import { useGetBooksQuery } from "../../services/booksSlice";
import {
  Row,
  Col,
  Image,
  ListGroup,
  Card,
  Button,
  Form,
} from "react-bootstrap";
import Rating from "../../components/Rang/Rang";
import { useState } from "react";

const BooksDetails = () => {
  const { book_id } = useParams();
  const [qty, setQty] = useState(0);
  const { data, isError, isLoading, error } = useGetBooksQuery(
    `books/${book_id}`
  );
  console.log(
    "🚀 ~ file: BooksDetails.tsx ~ line 6 ~ BooksDetails ~ data",
    data
  );

  return (
    <div className="container_detail">
      <div className="button_back">
        <Link to="/books" className="btn btn-light my-3">
          Go to
        </Link>
      </div>
      <Row style={{width: '100%'}}>
        <Col xl={6} lg={5} md={4} sm={3}>
          <Image className="img" src={data?.image} alt={data?.title} fluid />
        </Col>
        <Col xl={3} lg={3} md={3} sm={3}>
          <ListGroup variant="flush">
            <ListGroup.Item>
              <h4>{data?.title}</h4>
            </ListGroup.Item>
            <ListGroup.Item>
              <h4>{data?.subtitle}</h4>
            </ListGroup.Item>
            <ListGroup.Item>
              <Row>
                <Col>Autor:</Col>
                <Col>
                  <h4>{data?.authors}</h4>
                </Col>
              </Row>
            </ListGroup.Item>
            <ListGroup.Item>
              <Row>
                <Col>Editorial:</Col>
                <Col>
                  <h4>{data?.publisher}</h4>
                </Col>
              </Row>
            </ListGroup.Item>
            <ListGroup.Item>
              <Row>
                <Col>ISBN:</Col>
                <Col>{data?.isbn10}</Col>
              </Row>
            </ListGroup.Item>
            <ListGroup.Item>
              <Row>
                <Col>Puntuacion:</Col>
                <Col>
                  <ReactStars
                    size={24}
                    color2={"#ffc754"}
                    value={parseInt(data?.rating)}
                  />
                </Col>
              </Row>
            </ListGroup.Item>
            <ListGroup.Item>Price: {data?.price}</ListGroup.Item>
          </ListGroup>
        </Col>
        <Col xl={3} lg={3} md={3} sm={1}>
          <Card>
            <ListGroup variant="flush">
              <ListGroup.Item>
                <Row>
                  <Col>
                    <h4> Add to Cart:</h4>
                  </Col>
                </Row>
              </ListGroup.Item>
              <ListGroup.Item>
                <Row>
                  <Col>Qty</Col>
                  <Col>
                    <Form.Control
                      as="select"
                      value={qty}
                      onChange={(e: any) => setQty(e.target.value)}
                    >
                      <option value={1}>{1}</option>
                      <option value={2}>{2}</option>
                      <option value={3}>{3}</option>
                      <option value={4}>{4}</option>
                      <option value={5}>{5}</option>
                      <option value={6}>{6}</option>
                      <option value={7}>{7}</option>
                      <option value={8}>{8}</option>
                      <option value={9}>{9}</option>
                      <option value={10}>{10}</option>
                    </Form.Control>
                  </Col>
                </Row>
              </ListGroup.Item>

              <ListGroup.Item>
                <Button /* 
                      onClick={addToCartHandler} */
                  className="btn-block"
                  type="button"
                >
                  Add To Cart
                </Button>
              </ListGroup.Item>
            </ListGroup>
          </Card>
        </Col>
      </Row>
      <Row className="mb-5">
        <Col></Col>
        <Col>
          <h3>Descripciopn:</h3>
          <p>{data?.desc}</p>
        </Col>
      </Row>
    </div>
  );
};

export default BooksDetails;
