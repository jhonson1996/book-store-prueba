const express = require("express");
const Stripe = require("stripe");
const stripe = new Stripe("sk_test_51HvnNeL30FHPDItuoGsgLApAWfAStiSUTUHfEmStEVAQdFv3SyJfgjlIQKVgLnAZybnYr8uWbumVUWi7yI32sTwX00R2DC05Z8");

const cors = require("cors");

const app = express();

app.use(cors({ origin: "http://localhost:3000" }));
app.use(express.json());

app.post("/api/checkout", async (req, res) => {
  // you can get more data to find in a database, and so on
  const { id, amount } = req.body;
  console.log('=================amount===================');
  console.log('id', id, 'amount', amount);
  console.log('====================================');
  try {
    const payment = await stripe.paymentIntents.create({
      amount,
      currency: "USD",
      automatic_payment_methods: { enabled: true },/* 
      confirm: true, //confirm the payment at the same time */
    });

    /* console.log(payment); */

    
    return res.status(200).json({
      clientSecret: payment.client_secret,
    });
  } catch (error) {
    console.log(error);
    return res.json({ messageError: error.raw.message });
  }

});

app.listen(3001, () => {
  console.log("Server on port", 3001);
});